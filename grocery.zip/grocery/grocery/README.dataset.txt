# Shopping > 2023-06-03 3:51pm
https://universe.roboflow.com/tyler-durden/shopping-7rbo9

Provided by a Roboflow user
License: MIT

